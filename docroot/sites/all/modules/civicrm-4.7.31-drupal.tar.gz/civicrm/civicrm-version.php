<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.7.31',
                'cms'      => 'Drupal',
                'revision' => '' );
}

