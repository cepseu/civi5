uk.co.vedaconsulting.mailchimp
==============================
The new extension builds on the existing work done by the science gallery, adding the ability to pick the Mailchimp List the CiviCRM group should be integrated to aswell as making the entire process a much simpler one to setup.

Install the CiviCRM Mailchimp Extension

1. Download extension from https://github.com/veda-consulting/uk.co.vedaconsulting.mailchimp/releases/latest.
2. Unzip / untar the package and place it in your configured extensions directory.
3. When you reload the Manage Extensions page the new “Mailchimp” extension should be listed with an Install link.
4. Proceed with install.

To configure the extension please follow the link below.

http://www.vedaconsulting.co.uk/technical/civicrm-mailchimp/
