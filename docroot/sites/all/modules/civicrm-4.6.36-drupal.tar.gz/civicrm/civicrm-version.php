<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.6.36',
                'cms'      => 'Drupal',
                'revision' => '' );
}

