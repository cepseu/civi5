<?php print render($content); ?>
